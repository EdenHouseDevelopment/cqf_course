For Python Quants Bootcamp
==========================

This is the Gist for **Day 3** of the **For Python Quants Bootcamp** in London, 13.-15. November 2018 (http://fpq.io)

<img src="http://hilpisch.com/images/tpq_bootcamp_shadow.png" width=300px>


Short Link (Main Gist)
----------------------
http://bit.ly/fpq_lon_2018



The Python Quants
=================
http://twitter.com/dyjh

team@tpq.io | http://fpq.io

http://pyalgo.tpq.io | http://certificate.tpq.io

<img src="http://hilpisch.com/tpq_logo.png" width=300px>

