For Python Quants Bootcamp
==========================

This is the Gist the **For Python Quants Bootcamp** in London, 13.-15. November 2018 (http://fpq.io)

<img src="http://hilpisch.com/images/tpq_bootcamp_shadow.png" width=300px>


Main Gist & Day 1
-----------------
http://bit.ly/fpq_lon_2018

Other Gists
------------
Day 2: https://gist.github.com/f468acdd3dd1f6582db282708c18ca18

Day 3: https://gist.github.com/03e4d5e430959b60c2aa0c2f56a29194


Slides
------
full deck: http://hilpisch.com/fpq_lon_2018.pdf

overview only: http://hilpisch.com/fpq_lon_2018_overview.pdf


Wifi
----

Fitch Guest

Ft1ch#2016#!


Twitter Handle
---------------

http://twitter.com/dyjh

Recommended Books
-----------------
* Jake VanderPlas (2016): Python Data Science Handbook. O'Reilly.
* Wes McKinney (2017): Python for Data Analysis. 2nd ed., O'Reilly.
* Luciano Ramalho (2015): Fluent Python. O'Reilly.

Python Cheat Sheets
-------------------
* **Python**: https://s3.amazonaws.com/assets.datacamp.com/blog_assets/PythonForDataScience.pdf
* **NumPy**: https://s3.amazonaws.com/assets.datacamp.com/blog_assets/Numpy_Python_Cheat_Sheet.pdf
* **pandas**: https://s3.amazonaws.com/assets.datacamp.com/blog_assets/Python_Pandas_Cheat_Sheet_2.pdf
* **SciPy**: https://s3.amazonaws.com/assets.datacamp.com/blog_assets/Python_SciPy_Cheat_Sheet_Linear_Algebra.pdf
* **matplotlib**: https://s3.amazonaws.com/assets.datacamp.com/blog_assets/Python_Matplotlib_Cheat_Sheet.pdf


Setting Up the Python Environment (Windows)
===========================================

Miniconda
---------

How to install Miniconda:

https://conda.io/docs/user-guide/install/windows.html

Python
------
See http://conda.io

Also see https://conda.io/docs/_downloads/conda-cheatsheet.pdf

About managing environments: https://conda.io/docs/user-guide/tasks/manage-environments.html

To create an environment execute in the terminal ("command prompt"):

    conda create -n fpq python=3.6
    conda activate fpq

To install Python packages and start Jupyter execute in the terminal:

    conda install ipython jupyter numpy pandas scikit-learn matplotlib pytables
    jupyter notebook


Setting Up the Python Environment (Mac)
==============================================

Mac OS
------
Installing the `brew` package manager:

https://brew.sh/

Some OS tools:

    brew install wget screen [MORE IF NEEDED]


Miniconda
---------
To download and install it:

    wget https://repo.continuum.io/miniconda/Miniconda3-latest-Linux-x86_64.sh -O miniconda.sh
    bash miniconda.sh

Open **new shell instance** to activate the Python installation.


Python
------
See http://conda.io

Also see https://conda.io/docs/_downloads/conda-cheatsheet.pdf

To create an environment execute:

    conda create -n fpq python=3.6
    conda activate fpq

To install Python packages and start Jupyter execute in the terminal:

    conda install ipython jupyter numpy pandas scikit-learn matplotlib pytables
    jupyter notebook


Setting Up the Python Environment (Linux)
=========================================

Linux OS
--------
OS updates and tools:

    apt-get update
    apt-get upgrade
    apt-get install wget bzip2 screen vim gcc


Miniconda
---------
To download and install it:

    wget https://repo.continuum.io/miniconda/Miniconda3-latest-Linux-x86_64.sh -O miniconda.sh
    bash miniconda.sh

Open a **new shell instance** to activate the Python installation.


Python
------
See http://conda.io

Aslo see https://conda.io/docs/_downloads/conda-cheatsheet.pdf

To create an environment execute:

    conda create -n fpq python=3.6
    source activate fpq

To install Python packages and start Jupyter execute in the terminal:

    conda install ipython jupyter numpy pandas scikit-learn matplotlib pytables
    jupyter notebook


Some Docker Basics
===================

[Not needed for the bootcamp.]

Linux/Mac
---------
To test whether it is installed, open a terminal window and type:

    docker version


To run a docker container type:

    docker run -ti -h fpq -p 8888:8888 ubuntu:latest /bin/bash

Windows
-------
Open the Docker Quickstart Terminal.

To run a docker container type:

    docker run -ti -h fpq -p 8888:8888 -e MACHINE_IP=$(docker-machine ip) ubuntu:latest /bin/bash


Links to Platforms
==================

Quant Platform
--------------
general: http://pqp.io

DigitalOcean (just in case)
---------------------------
setting up an account with 10 USD starting credit:
https://m.do.co/c/fbe512dd3dac

Plotly
------
general: http://plot.ly

getting started: https://plot.ly/python/getting-started/

Oanda
-----
general: http://oanda.com

demo account: https://www.oanda.com/register/#/sign-up/demo

The Python Quants
=================
http://twitter.com/dyjh

team@tpq.io | http://fpq.io

http://pyalgo.tpq.io | http://certificate.tpq.io

<img src="http://hilpisch.com/tpq_logo.png" width=300px>

