# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Thu Nov 15 15:46:17 2018)---
import numpy as np
import tpqoa
import tpqoa.toqoa
import tpqoa as tq
runfile('C:/Users/Admin/.spyder-py3/temp.py', wdir='C:/Users/Admin/.spyder-py3')
!pip install git-https://github.com/yhiplisch/tpqoa.git

## ---(Thu Nov 15 16:18:58 2018)---
!pip install git-https://github.com/yhiplisch/tpqoa.git
import ujson
!pip install git-https://github.com/yhiplisch/tpqoa.git
pip install git+https://github.com/yhilpisch/tpqoa.git
!pip install git+https://github.com/yhilpisch/tpqoa.git
runfile('C:/Users/Admin/.spyder-py3/temp.py', wdir='C:/Users/Admin/.spyder-py3')
runfile('C:/Users/Admin/SMATrader.py', wdir='C:/Users/Admin')
import tpqoa
!pip install git+https://github.com/yhilpisch/tpqoa.git
import tpqoa
!pwd
"cd
!cd

import tpqoa
runfile('C:/Users/Admin/SMATrader.py', wdir='C:/Users/Admin')