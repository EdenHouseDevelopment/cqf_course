# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Thu Nov 15 10:16:21 2018)---
runfile('C:/Users/Admin/.spyder/cqf day 3 session 1.py', wdir='C:/Users/Admin/.spyder')
runfile('C:/Users/Admin/.spyder/tick server.py', wdir='C:/Users/Admin/.spyder')
runfile('C:/Users/Admin/.spyder/tick client.py', wdir='C:/Users/Admin/.spyder')
runfile('C:/Users/Admin/.spyder/tick client.py', wdir='C:/Users/Admin/.spyder')
runfile('C:/Users/Admin/.spyder/tick collector.py', wdir='C:/Users/Admin/.spyder')
%run "tick collecter.py"
%run tick collecter.py
%run tick_collecter
runfile('C:/Users/Admin/.spyder/tick_collector.py', wdir='C:/Users/Admin/.spyder')
raw.info()
runfile('C:/Users/Admin/.spyder/tick_collector.py', wdir='C:/Users/Admin/.spyder')
raw.resample('5s').last()
raw.resample('5s',label='right').last()
runfile('C:/Users/Admin/.spyder/tick_collector.py', wdir='C:/Users/Admin/.spyder')
data
pip install git+git://github.com/yhilpisch/tpqoa
!conda install git+https://github.com/yhilpisch/tpqoa.git
!conda install git+git://github.com/yhilpisch/tpqoa.git
!conda install ujson

## ---(Thu Nov 15 15:57:33 2018)---
!pip install v20
!conda install ujson