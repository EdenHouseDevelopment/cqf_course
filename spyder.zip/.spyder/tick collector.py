# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 10:34:39 2018

@author: Admin
"""

import zmq
import datetime
import pandas as pd

context = zmq.Context()
socket = context.socket(zmq.SUB)

print("Creating ZMQ Client")
socket.connect('tcp://127.0.0.1:4242')

socket.setsockopt_string(zmq.SUBSCRIBE, u'')

raw = pd.DataFrame()

while True:
    
    msg = socket.recv_string()
    
    t = datetime.datetime.now()
    
    print(' {} '.format(str(t)) + msg)
    
    symbol, price = msg.split()
    
    raw = raw.append(pd.DataFrame({symbol: float(price)},index=[t]))
    
    
    

