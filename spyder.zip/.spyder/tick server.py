# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
#
# tick_server.py
# I think this is our random walk generator
#

import zmq
import time
import random

context = zmq.Context()
socket = context.socket(zmq.PUB)

print("Creating ZMQ Publisher")
socket.bind('tcp://127.0.0.1:4242')

AAPL_price = 100.

while True:
    AAPL_price += random.gauss(0,1) * 0.5
    msg = 'AAPL {:.3f}'.format(AAPL_price)
    
    print(msg)
    
    socket.send_string(msg)
    
    time.sleep(random.random() * 2)


